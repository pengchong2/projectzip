package com.flyaudio.entities;

public class FlyFuctionBox {

	public static final int GPS = 1;
        public static final int DISC = 2;
        public static final int MEDIA = 3;
        public static final int RADIO = 4;
	public static final int BLUE_MUSIC = 5;
	public static final int BLUETH = 6;
	public static final int CAR_INFO = 7;
	public static final int TIRE_PRE = 8;
	public static final int DRIVE_VIDEO = 9;
	public static final int AC = 10;
	public static final int TV = 11;
	public static final int AUXIN = 12;
	public static final int SETTINGS = 13;
	public static final int REAR_SEAT = 14;
	public static final int UNKNOW_TYPE = 15;

}
